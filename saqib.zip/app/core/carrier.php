<?php


interface carrier {
    
    public function carrier_init() {
        
        // prep file for correct setup for carrier
        
    }
    
}

