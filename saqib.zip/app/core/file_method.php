<?php

/**
 * Class File Method
 * @author Saqib
 *
 */
class File_Method {
    
    public static $append = 'a';
    public static $write = 'w';
    
}