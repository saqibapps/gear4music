<?php


class Transport implements carrier {
    
    public function carrier_init() {
        
        // prep for carrier
        
    }
    
    public function royalmail() {
        
    }
    
    public function ups( ) {
        ;
    }
    
    public function anc() {
        
    }
    
}